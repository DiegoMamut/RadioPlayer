/** Automatically generated file. DO NOT MODIFY */
package uk.co.jarofgreen.JustADamnCompass;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}