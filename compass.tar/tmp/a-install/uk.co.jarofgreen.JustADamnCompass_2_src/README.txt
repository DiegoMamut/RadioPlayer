Just a Damn Compass
===================

This Android app, for any phone Android 2.1+ and above with a compass, is just a compass. That's it.

If you are still unsure about this concept, let us try some FAQ's.

* How many themes does it have?
1

* Does it have any sound effects?
No

See? It really is just a compass.